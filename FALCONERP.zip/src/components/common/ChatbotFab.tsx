import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, MessageCircle } from 'lucide-react'; // Import MessageCircle and X

interface ChatbotFabProps {
  initialDelay?: number;
  // bottomOffset is the standard spacing from the viewport bottom (e.g., 16px)
  bottomOffset: number;
  // headerHeight is the actual measured height of the Header component (bottom nav on mobile)
  headerHeight: number;
  isMobile: boolean; // Indicates if currently in mobile view
}

const ChatbotFab: React.FC<ChatbotFabProps> = ({ initialDelay = 4, bottomOffset, headerHeight, isMobile }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ type: 'bot' | 'user'; text: string; id: number }>>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [messageIdCounter, setMessageIdCounter] = useState(0);

  const initialBotGreeting = "Hello there! I am Vision, your human-realistic AI assistant, proudly powered by Fedrix MediaLab. Please note, I am currently operating in an offline test model. How may I assist you today?";
  const quickActions = [
    { id: 'about', text: 'About Vision' },
    { id: 'capabilities', text: 'My Capabilities' },
    { id: 'offline_model', text: 'About this Test Model' },
    { id: 'contact', text: 'Contact Fedrix MediaLab' },
    { id: 'reset', text: 'Start Over' }
  ];

  const getBotResponse = (actionId: string): string => {
    switch (actionId) {
      case 'about':
        return "Vision is an advanced AI conversational agent meticulously designed by Fedrix MediaLab to optimize user interactions, provide rapid, precise information, and enhance operational efficiency. My core purpose is to simplify complex processes through intuitive dialogue.";
      case 'capabilities':
        return "As an enterprise-grade AI (currently in development), Vision is engineered to handle intricate queries, automate routine administrative tasks, deliver insightful data analytics, and provide comprehensive customer support across diverse business modules. In this test environment, I can offer predefined answers and demonstrate conversational flow.";
      case 'offline_model':
        return "This version of Vision is an offline test model, designed for demonstration and internal testing purposes. It does not connect to live data or external services. All responses are predefined to showcase potential interactions and capabilities without real-time processing.";
      case 'contact':
        return "For direct support, strategic partnerships, or detailed inquiries about Fedrix MediaLab's solutions, please visit our official website at www.fedrixgroup.com or reach out to our dedicated support team via support@fedrixgroup.com. We appreciate your interest and patience with this test model.";
      case 'reset':
        setMessages([]);
        return initialBotGreeting;
      default:
        return "I apologize, I'm still learning to process nuanced requests in this test model. Could you please select one of the quick action pills below? They cover my primary functions and information.";
    }
  };

  const handleSendMessage = (text: string, type: 'user' | 'bot' = 'user') => {
    const newMessage = { type, text, id: messageIdCounter };
    setMessages((prevMessages) => [...prevMessages, newMessage]);
    setMessageIdCounter((prev) => prev + 1);

    if (type === 'user') {
      setIsTyping(true);
      const responseActionId = quickActions.find(qa => qa.text === text)?.id || 'default_fallback';
      setTimeout(() => {
        setIsTyping(false);
        const botResponse = getBotResponse(responseActionId);
        handleSendMessage(botResponse, 'bot');
      }, 1500);
    }
  };

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        handleSendMessage(initialBotGreeting, 'bot');
      }, 1000);
    }
  }, [isOpen, messages.length]);

  // Read fabSpacing and fabSize from root CSS variables (defined in globals.css)
  const [fabSize, setFabSize] = useState(60); // Default, will be updated
  const [fabSpacing, setFabSpacing] = useState(16); // Default, will be updated

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const rootStyles = getComputedStyle(document.documentElement);
      setFabSize(parseInt(rootStyles.getPropertyValue('--fab-size')) || 60);
      setFabSpacing(parseInt(rootStyles.getPropertyValue('--fab-spacing')) || 16);
    }
  }, []);

  // Calculate dynamic bottom position, ensuring valid numbers for Framer Motion
  const currentHeaderHeight = typeof headerHeight === 'number' && !isNaN(headerHeight) ? headerHeight : 0;
  const currentBottomOffset = typeof bottomOffset === 'number' && !isNaN(bottomOffset) ? bottomOffset : 0;

  // If it's mobile, position it above the header, maintaining the bottomOffset spacing.
  // Otherwise (desktop), just use the bottomOffset from the viewport edge.
  const dynamicBottomPosition = isMobile
    ? (currentHeaderHeight + currentBottomOffset) // Mobile: header height + standard bottom spacing
    : currentBottomOffset; // Desktop: standard bottom offset from viewport edge

  return (
    <motion.div
      className="fixed z-[999]" // Increased z-index to ensure it's always on top
      style={{
        right: `${fabSpacing}px`, // Use numeric fabSpacing
        bottom: `${dynamicBottomPosition}px`, // Use numeric dynamicBottomPosition
      }}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: "spring", stiffness: 100, damping: 20, delay: initialDelay }}
    >
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="bg-[#0A1128] text-white rounded-lg shadow-xl overflow-hidden
                       w-80 h-[400px] flex flex-col border border-blue-700
                       md:w-96 md:h-[500px]"
            initial={{ opacity: 0, y: 50, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.8 }}
            transition={{ type: "spring", stiffness: 150, damping: 25 }}
            style={{ marginBottom: `${fabSize}px` }} /* Ensures chat bubble clears the FABs when open on mobile */
          >
            {/* Chat Header */}
            <div className="flex justify-between items-center bg-[#00174F] p-3 text-lg font-semibold rounded-t-lg border-b border-blue-600">
              <span>Vision AI</span>
              <button onClick={() => setIsOpen(false)} className="text-white hover:text-gray-300 transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-grow p-4 overflow-y-auto space-y-3 custom-scrollbar">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.type === 'bot' ? 'justify-start' : 'justify-end'}`}
                >
                  <div className={`px-4 py-2 rounded-lg max-w-[80%] text-sm
                                   ${msg.type === 'bot' ? 'bg-blue-800 text-white rounded-bl-none' : 'bg-gray-700 text-white rounded-br-none'}`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-blue-800 text-white px-4 py-2 rounded-lg rounded-bl-none">
                    <div className="typing-animation dots-pulse">
                      <span></span><span></span><span></span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Actions / Powered By */}
            <div className="p-4 border-t border-blue-600 bg-[#00174F] rounded-b-lg">
              <div className="flex flex-wrap gap-2 mb-3">
                {quickActions.map((action) => (
                  <button
                    key={action.id}
                    onClick={() => handleSendMessage(action.text, 'user')}
                    className="px-4 py-2 text-sm bg-blue-700 hover:bg-blue-600 rounded-full transition-colors"
                  >
                    {action.text}
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-400 mt-2 text-center">
                Powered by{' '}
                <a href="https://www.fedrixgroup.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
                  Fedrix MediaLab
                </a>
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FAB Button to toggle chat */}
      <motion.button
        className={`rounded-full bg-blue-600 text-white shadow-lg flex items-center justify-center transition-all duration-300
                    ${isOpen ? 'opacity-0 scale-0 pointer-events-none' : 'opacity-100 scale-100 pulse-scale'}`}
        style={{
          width: `${fabSize}px`, // Use numeric fabSize
          height: `${fabSize}px`, // Use numeric fabSize
        }}
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        aria-label="Toggle Chatbot"
      >
        <MessageCircle size={32} />
      </motion.button>
    </motion.div>
  );
};

export default ChatbotFab;
