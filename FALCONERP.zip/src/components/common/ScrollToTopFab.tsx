import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUp } from 'lucide-react'; // Up arrow icon

interface ScrollToTopFabProps {
  scrollThreshold?: number; // How far down to scroll before appearing (in pixels)
  chatFabBottomOffset: number; // This is the base offset for ChatbotFab
  fabSize: number; // Prop passed from _app.tsx
  fabSpacing: number; // Prop passed from _app.tsx
  headerHeight: number; // Prop passed from _app.tsx (height of mobile fixed header)
  isMobile: boolean; // Prop passed from _app.tsx
}

const ScrollToTopFab: React.FC<ScrollToTopFabProps> = ({
  scrollThreshold = 200,
  chatFabBottomOffset,
  fabSize,
  fabSpacing,
  headerHeight,
  isMobile
}) => {
  const [isVisible, setIsVisible] = useState(false);

  // Handle scroll event to toggle visibility
  const handleScroll = useCallback(() => {
    if (typeof window !== 'undefined') {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    }
  }, []);

  // Attach/detach scroll listener
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.addEventListener('scroll', handleScroll, { passive: true });
      return () => window.removeEventListener('scroll', handleScroll);
    }
  }, [handleScroll]);

  // Function to smoothly scroll to the top
  const scrollToTop = useCallback(() => {
    if (typeof window !== 'undefined') {
      window.scrollTo({
        top: 0,
        behavior: 'smooth',
      });
    }
  }, []);

  // Ensure props are valid numbers for calculation (defensive coding)
  const currentHeaderHeight = typeof headerHeight === 'number' && !isNaN(headerHeight) ? headerHeight : 0;
  const currentChatFabBottomBaseOffset = typeof chatFabBottomOffset === 'number' && !isNaN(chatFabBottomOffset) ? chatFabBottomOffset : 0;
  const currentFabSize = typeof fabSize === 'number' && !isNaN(fabSize) ? fabSize : 0;
  const currentFabSpacing = typeof fabSpacing === 'number' && !isNaN(fabSpacing) ? fabSpacing : 0;


  // Calculate dynamic bottom position for the 'animate' prop
  // This FAB should stack above the ChatbotFab.
  const calculatedBottomPosition = isMobile
    ? (currentHeaderHeight + currentChatFabBottomBaseOffset + currentFabSize + currentFabSpacing)
    : (currentChatFabBottomBaseOffset + currentFabSize + currentFabSpacing);


  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          className={`fixed bg-blue-600 text-white rounded-full shadow-lg z-[999] flex items-center justify-center cursor-pointer pulse-scale`} // Increased z-index
          style={{
            right: `${currentFabSpacing}px`, // Explicitly set right
            width: `${currentFabSize}px`, // Explicitly set width
            height: `${currentFabSize}px`, // Explicitly set height
            bottom: `${calculatedBottomPosition}px`, // Set bottom directly
          }}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          transition={{ type: "spring", stiffness: 150, damping: 25 }}
          onClick={scrollToTop}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <ArrowUp size={32} />
        </motion.button>
      )}
    </AnimatePresence>
  );
};

export default ScrollToTopFab;
