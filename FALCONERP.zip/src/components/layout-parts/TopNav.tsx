import React from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import { Mail } from 'lucide-react'; // Import Mail icon from Lucide React

interface TopNavProps {}

const TopNav: React.FC<TopNavProps> = () => {
  return (
    <motion.div
      className="fixed top-0 left-0 w-full flex justify-between items-center px-8 py-4 z-20 h-20" /* Explicit h-20 (80px) */
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.8 }}
    >
      {/* Logo - Increased size, now responsive */}
      <motion.div
        initial={{ x: -50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.9 }}
        className="w-[180px] h-[45px] md:w-[250px] md:h-[60px] flex-shrink-0" /* Parent div provides overall sizing context */
      >
        {/* CRITICAL FIX: Explicitly set position: 'relative' on the Link component's style prop */}
        <Link href="/" passHref className="h-full w-full block" style={{ position: 'relative' }}>
          <Image
            src="/images/WLogo.svg" // Updated to SVG
            alt="Falcon ERP Logo"
            fill // Use fill to make image responsive to parent's dimensions
            priority
            className="object-contain cursor-pointer" /* Image fills parent, maintains aspect ratio */
            sizes="(max-width: 768px) 180px, 250px" // Define sizes for performance
          />
        </Link>
      </motion.div>

      {/* Get in Touch Button - Now with Lucide Icon for reliability */}
      <motion.button
        className="px-4 py-2 rounded-full border border-[#00174F] bg-[#00174F] text-white
                   shadow-lg text-sm md:text-base font-semibold flex items-center gap-1
                   transition-all duration-300
                   hover:bg-[#002A80] hover:border-[#A0D4FF] hover:shadow-[0_0_25px_rgba(160,212,255,0.9)]"
        initial={{ x: 50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 1.0 }}
        onClick={() => alert("Navigating to Contact Us!")}
      >
        {/* Lucide Mail icon */}
        <Mail size={20} />
        <span>Get in Touch</span>
      </motion.button>
    </motion.div>
  );
};

export default TopNav;
