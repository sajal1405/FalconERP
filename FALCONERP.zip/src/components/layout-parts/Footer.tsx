import React from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import {
  Facebook, Twitter, Linkedin, Instagram, Youtube,
  Phone, Mail, MapPin, // Lucide icons for contact info
} from 'lucide-react'; // Import necessary Lucide icons

interface FooterProps {}

const Footer: React.FC<FooterProps> = () => {
  const currentYear = new Date().getFullYear();

  return (
    <motion.footer
      className="w-full bg-[#00174F] text-gray-300 py-10 px-4 md:px-8 lg:px-12 mt-16 rounded-t-3xl border-t border-blue-800 shadow-inner-top"
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto flex flex-col items-center">
        {/* Main Footer Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 lg:gap-16 w-full text-center md:text-left">

          {/* Section 1: About FALCON ERP (Logo as Title) */}
          <div className="flex flex-col items-center md:items-start space-y-4">
            {/* CRITICAL FIX: Explicitly set position: 'relative' on the Link component's style prop */}
            <Link href="/" passHref className="mb-4 w-[180px] h-[45px] block" style={{ position: 'relative' }}>
              <Image
                src="/images/WLogo.svg" // Updated to SVG
                alt="Falcon ERP Logo"
                fill // Use fill to make image responsive to parent's dimensions
                priority
                className="object-contain cursor-pointer" // Image fills parent, maintains aspect ratio
                sizes="180px" // Define sizes for performance
              />
            </Link>
            <ul className="space-y-2 text-sm">
              <li><Link href="#about" className="hover:text-blue-400 transition-colors">About Us</Link></li>
              <li><Link href="#business-opportunity" className="hover:text-blue-400 transition-colors">Business Opportunity</Link></li>
              <li><Link href="#career" className="hover:text-blue-400 transition-colors">Career</Link></li>
              <li><Link href="/faqs" className="hover:text-blue-400 transition-colors">FAQ</Link></li>
            </ul>
          </div>

          {/* Section 2: Industry */}
          <div className="flex flex-col items-center md:items-start space-y-4">
            <h3 className="text-xl font-bold text-white mb-2 pb-1 border-b-2 border-blue-500 footer-title">Industry</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="#trading" className="hover:text-blue-400 transition-colors">Trading</Link></li>
              <li><Link href="#manufacturing" className="hover:text-blue-400 transition-colors">Manufacturing</Link></li>
              <li><Link href="#consulting" className="hover:text-blue-400 transition-colors">Consulting</Link></li>
              <li><Link href="#construction" className="hover:text-blue-400 transition-colors">Construction</Link></li>
            </ul>
          </div>

          {/* Section 3: Services */}
          <div className="flex flex-col items-center md:items-start space-y-4">
            <h3 className="text-xl font-bold text-white mb-2 pb-1 border-b-2 border-blue-500 footer-title">Services</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="#support" className="hover:text-blue-400 transition-colors">Support</Link></li>
              <li><Link href="#enhancement" className="hover:text-blue-400 transition-colors">Enhancement</Link></li>
              <li><Link href="#customization" className="hover:text-blue-400 transition-colors">Customization</Link></li>
            </ul>
          </div>

          {/* Section 4: Contact Us */}
          <div className="flex flex-col items-center md:items-start space-y-4">
            <h3 className="text-xl font-bold text-white mb-2 pb-1 border-b-2 border-blue-500 footer-title">Contact Us</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center justify-center md:justify-start gap-2">
                <MapPin size={16} className="flex-shrink-0 text-blue-400" />
                <span>
                  FALCON ERP<br/>
                  27020, Sharjah<br/>
                  United Arab Emirates
                </span>
              </li>
              <li className="flex items-center justify-center md:justify-start gap-2">
                <Phone size={16} className="flex-shrink-0 text-blue-400" />
                <a href="tel:+97165624427" className="hover:text-blue-400 transition-colors">+971 6 5624427</a>
              </li>
              <li className="flex items-center justify-center md:justify-start gap-2">
                <Phone size={16} className="flex-shrink-0 text-blue-400" />
                <a href="tel:+971506330157" className="hover:text-blue-400 transition-colors">+971 50 6330157</a>
              </li>
              <li className="flex items-center justify-center md:justify-start gap-2">
                <Mail size={16} className="flex-shrink-0 text-blue-400" />
                <a href="mailto:sales@falconerp.com" className="hover:text-blue-400 transition-colors">sales@falconerp.com</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Social Media Icons */}
        <div className="w-full flex justify-center md:justify-start mt-8 pt-6 border-t border-blue-700/50 space-x-6">
          <a href="https://www.facebook.com/falconerpme/" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="text-gray-400 hover:text-blue-400 transition-colors">
            <Facebook size={24} />
          </a>
          <a href="https://x.com/falconerpuae" target="_blank" rel="noopener noreferrer" aria-label="X (Twitter)" className="text-gray-400 hover:text-blue-400 transition-colors">
            <Twitter size={24} /> {/* Using Twitter icon for X, as it's common */}
          </a>
          <a href="https://www.linkedin.com/company/falconerp" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="text-gray-400 hover:text-blue-400 transition-colors">
            <Linkedin size={24} />
          </a>
          <a href="https://www.instagram.com/falconerpme/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-gray-400 hover:text-blue-400 transition-colors">
            <Instagram size={24} />
          </a>
          <a href="https://www.youtube.com/channel/UCauLEksxFmAgfvaD4XLECKA" target="_blank" rel="noopener noreferrer" aria-label="YouTube" className="text-gray-400 hover:text-blue-400 transition-colors">
            <Youtube size={24} />
          </a>
        </div>

        {/* Copyright Line */}
        <div className="w-full text-center text-xs text-gray-500 mt-6 pt-4 border-t border-blue-700/30">
          © {currentYear} FALCON ERP. All rights reserved. Powered by{' '}
          <a href="https://www.fedrixgroup.com" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
            Fedrix MediaLab
          </a>.
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;
