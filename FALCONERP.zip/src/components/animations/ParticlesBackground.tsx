import React, { useCallback, useMemo } from "react";
import Particles from "@tsparticles/react";
import type { Container, Engine } from "tsparticles-engine"; // Corrected import source for types
import { loadSlim } from "@tsparticles/slim";

const ParticlesBackground: React.FC = () => {
  const particlesInit = useCallback(async (engine: Engine) => {
    console.log("Particles engine initialized."); // Debugging log
    await loadSlim(engine);
  }, []);

  const particlesLoaded = useCallback(async (container?: Container) => {
    console.log("Particles container loaded:", container); // Debugging log
  }, []);

  const options = useMemo(() => ({
    background: {
      color: {
        value: "#0a1128", // This is the background color of the canvas itself
      },
      opacity: 0, // IMPORTANT: Keep this at 0 so it's transparent and your main page background shows
    },
    fpsLimit: 60,
    interactivity: {
      events: {
        onClick: { // Optional: Enable click interaction for testing
          enable: true,
          mode: "push",
        },
        onHover: {
          enable: true,
          mode: "repulse",
        },
        resize: true,
      },
      modes: {
        push: {
          quantity: 4,
        },
        repulse: {
          distance: 100,
          duration: 0.4,
        },
      },
    },
    particles: {
      color: {
        value: "#80DEEA", // Changed to a brighter cyan for better visibility
      },
      links: {
        color: "#80DEEA", // Bright cyan lines
        distance: 150,
        enable: true,
        opacity: 0.4,
        width: 1,
      },
      move: {
        direction: "none",
        enable: true,
        outModes: {
          default: "bounce",
        },
        random: false,
        speed: 1,
        straight: false,
      },
      number: {
        density: {
          enable: true,
          area: 800,
        },
        value: 80,
      },
      opacity: {
        value: 0.7, // Slightly increased opacity for particles
      },
      shape: {
        type: "circle",
      },
      size: {
        value: { min: 1, max: 3 },
      },
    },
    detectRetina: true,
    fullScreen: {
      enable: true,
      zIndex: -1, // Crucial: Place it behind all other content
    }
  }), []);

  return <Particles id="tsparticles" init={particlesInit} loaded={particlesLoaded} options={options} />;
};

export default ParticlesBackground;
