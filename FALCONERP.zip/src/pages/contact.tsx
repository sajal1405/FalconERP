import React from 'react';
import { motion } from 'framer-motion';

const ContactPage: React.FC = () => {
  return (
    <motion.div
      key="contact"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="w-full h-full flex items-center justify-center bg-gradient-to-br from-red-700 to-purple-900 rounded-lg shadow-xl p-8"
    >
      <h1 className="text-5xl font-extrabold text-white text-center">Contact Us</h1>
    </motion.div>
  );
};

export default ContactPage;
