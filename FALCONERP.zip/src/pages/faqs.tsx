import React from 'react';
import { motion } from 'framer-motion';

const FAQsPage: React.FC = () => {
  return (
    <motion.div
      key="faqs"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="w-full h-full flex items-center justify-center bg-gradient-to-br from-cyan-700 to-teal-900 rounded-lg shadow-xl p-8"
    >
      <h1 className="text-5xl font-extrabold text-white text-center">Frequently Asked Questions</h1>
    </motion.div>
  );
};

export default FAQsPage;
