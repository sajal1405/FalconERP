import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import type { AppProps } from 'next/app';
import { motion, AnimatePresence } from 'framer-motion';
import Head from 'next/head'; // Import Head component

import '../styles/globals.css'; // Global CSS imported ONLY here

import Header from '../components/header/Header'; // Your existing Header component
import TopNav from '../components/layout-parts/TopNav';
import Preloader from '../components/preloader/Preloader';
import ParticlesBackground from '../components/animations/ParticlesBackground';
import ChatbotFab from '../components/common/ChatbotFab';
import ScrollToTopFab from '../components/common/ScrollToTopFab';
import Footer from '../components/layout-parts/Footer';

import HomePage from './index';
import AboutPage from './about';
import ServicesPage from './services';
import FAQsPage from './faqs';
import ContactPage from './contact';

export default function App({ Component, pageProps }: AppProps) {
  const [activePage, setActivePage] = useState('home');
  const [isLoading, setIsLoading] = useState(true); // Now controlled by Preloader on mobile

  // State for dynamically measured heights - initialized to 0 for SSR safety
  const [viewportHeight, setViewportHeight] = useState(0);
  const [topNavHeight, setTopNavHeight] = useState(0);
  const [headerHeight, setHeaderHeight] = useState(0); // For bottom header on mobile, top header on desktop
  const [isMobile, setIsMobile] = useState(false); // New state to track mobile view

  const topNavRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null); // Ref for the fixed header's wrapper div

  // Measure heights dynamically - wrapped in useCallback for efficiency and memoization
  const measureHeights = useCallback(() => {
    if (typeof window !== 'undefined') { // Ensure window is defined (client-side)
      setViewportHeight(window.innerHeight);
      setIsMobile(window.innerWidth < 768); // Update isMobile state based on window.innerWidth

      // Measure TopNav height
      if (topNavRef.current) {
        setTopNavHeight(topNavRef.current.offsetHeight);
      } else {
        setTopNavHeight(80); // Fallback to a reasonable default (h-20)
      }

      // Measure Header height (this ref is on the wrapper div for fixed positioning)
      if (headerRef.current) {
        const actualHeader = headerRef.current.querySelector('header');
        const currentHeaderHeight = actualHeader ? actualHeader.offsetHeight : 80;
        // On mobile, the header has 'bottom-4' (16px) margin, which contributes to its overall space.
        // So, its measured height for layout purposes should include that.
        setHeaderHeight(window.innerWidth < 768 ? (currentHeaderHeight + 16) : currentHeaderHeight);
      } else {
        setHeaderHeight(80); // Fallback to a reasonable default
      }
    }
  }, []);

  useEffect(() => {
    measureHeights(); // Initial measurement on component mount

    // Add resize listener only on client-side
    if (typeof window !== 'undefined') {
      window.addEventListener('resize', measureHeights, { passive: true }); // Added { passive: true }
      return () => window.removeEventListener('resize', measureHeights);
    }
  }, [measureHeights]);


  // Preloader logic handled by Preloader.tsx itself and onComplete callback
  const handlePreloaderComplete = useCallback(() => {
    setIsLoading(false);
    console.log('Preloader finished');
  }, []);

  const renderPageContent = () => {
    // Pass calculated heights and isMobile state to HomePage for precise hero section sizing
    switch (activePage) {
      case 'home':
        return (
          <HomePage
            viewportHeight={viewportHeight}
            topNavHeight={topNavHeight}
            headerHeight={headerHeight}
            isMobile={isMobile} // Pass isMobile state
          />
        );
      case 'about':
        return <AboutPage />;
      case 'services':
        return <ServicesPage />;
      case 'faqs':
        return <FAQsPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <HomePage />;
    }
  };

  const fabSize = 60; // from globals.css --fab-size (var(--fab-size))
  const fabSpacing = 16; // from globals.css --fab-spacing (var(--fab-spacing))

  // Chatbot FAB is the lowest, it sits at `fabSpacing` from the viewport bottom.
  const chatbotFabBottomBaseOffset = fabSpacing;

  // Calculate the total combined height of all fixed elements at the bottom of the viewport on mobile.
  const mobileFixedElementsTotalHeight = headerHeight + chatbotFabBottomBaseOffset + fabSize + fabSpacing + fabSize;

  // Determine padding for main content's bottom.
  const dynamicPaddingBottom = isMobile
    ? `${mobileFixedElementsTotalHeight + 400}px` // Maintain generous buffer for mobile for now
    : '0px';

  return (
    // Removed p-8 from this root div. This div defines the main background for the entire page.
    <div className="relative min-h-screen bg-gray-950 flex flex-col items-center overflow-hidden font-inter">
      <Head>
        {/* Favicon */}
        <link rel="icon" href="/BIcon.svg" />
        <link rel="mask-icon" href="/BIcon.svg" color="#00174F" /> {/* For Safari pinned tabs */}

        {/* PWA Manifest */}
        <link rel="manifest" href="/manifest.json" />

        {/* iOS Specific PWA Meta Tags */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="FALCON ERP" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" /> {/* Use a high-res icon for Apple devices */}
        <link rel="apple-touch-startup-image" href="/splash_screens/iPhone_15_Pro_Max_landscape.png" media="(device-width: 430px) and (device-height: 932px) and (-webkit-device-pixel-ratio: 3) and (orientation: landscape)" />
        {/* ... add more splash screens for different devices as needed (recommended but complex) */}
        <link rel="apple-touch-startup-image" href="/splash_screens/iPhone_15_Pro_Max_portrait.png" media="(device-width: 430px) and (device-height: 932px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)" />

        {/* Recommended modern PWA meta tag for fullscreen mode on mobile */}
        <meta name="mobile-web-app-capable" content="yes" /> {/* ADDED THIS LINE */}

        {/* Viewport Meta Tag for Responsive Design */}
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />

        {/* Theme Color for Android Chrome (changes address bar color) */}
        <meta name="theme-color" content="#00174F" />

        {/* REMOVED: link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" / */}
      </Head>

      <ParticlesBackground />

      <AnimatePresence mode="wait">
        {isLoading && <Preloader onComplete={handlePreloaderComplete} isMobile={isMobile} />}
      </AnimatePresence>

      {/* Top Navigation - Fixed at top, with ref for measurement */}
      <div ref={topNavRef}>
        <TopNav />
      </div>

      {/* Header (bottom navbar on mobile, top-center on desktop), with ref for measurement */}
      {/* The 'bottom-4' class adds 16px of space below the header on mobile */}
      <div ref={headerRef} className="fixed z-50 bottom-4 md:top-8 md:bottom-auto left-1/2 -translate-x-1/2">
        <Header activePage={activePage} setActivePage={setActivePage} />
      </div>

      {/* Main Content Area - Renders the active page content */}
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 md:px-8"
            style={{
              paddingTop: `${topNavHeight}px`,
              paddingBottom: dynamicPaddingBottom
            }}>
        <AnimatePresence mode="wait">
          {renderPageContent()}
        </AnimatePresence>
      </main>

      {/* NEW: Footer component rendered here, OUTSIDE the main tag, at the root level */}
      {/* This ensures the Footer defines the absolute bottom of the scrollable content. */}
      <Footer />

      {/* Floating Action Buttons */}
      <ChatbotFab
        bottomOffset={chatbotFabBottomBaseOffset}
        headerHeight={isMobile ? headerHeight : 0}
        isMobile={isMobile}
      />
      <ScrollToTopFab
        chatFabBottomOffset={chatbotFabBottomBaseOffset}
        fabSize={fabSize}
        fabSpacing={fabSpacing}
        headerHeight={headerHeight}
        isMobile={isMobile}
      />

      {/* Background elements for visual enhancement */}
      <div className="absolute inset-0 z-0 opacity-10">
        <motion.div
          className="absolute w-64 h-64 bg-indigo-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob top-1/4 left-1/4"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 3, duration: 1 }}
        ></motion.div>
        <motion.div
          className="absolute w-64 h-64 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000 top-1/2 right-1/4"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 3.2, duration: 1 }}
        ></motion.div>
        <motion.div
          className="absolute w-64 h-64 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000 bottom-1/4 left-1/2"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 3.4, duration: 1 }}
        ></motion.div>
      </div>
    </div>
  );
}
